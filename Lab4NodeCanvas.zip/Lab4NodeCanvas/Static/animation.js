const playBtn = document.querySelector(".play-button");
const playCanvas = document.querySelector(".play-canvas-button");
const block = document.querySelector(".left-block-body");
const workplaceWrapper = document.querySelector(".workplace-wrapper");
const workplace = document.querySelector(".workplace");

let blockContent = block.innerHTML;
const height = block.offsetHeight;
const width = block.offsetWidth;
let raf = null;
let counter = 0;
let step = 0;
let dir = "right";
const cell = 20;
let x = 0;
let y = 0;
let interval = 0;
let canvas = "";
let ctx = "";

const setBlockSizes = () => {
  block.style.width = `${width}px`;
  block.style.height = `${height}px`;
};

const closeWorkplace = () => {
  clearInterval(interval);
  restartAnimation();
  canvas.classList.add("display-none");
  const square = document.querySelector(".square");
  if (square) square.remove();
  workplace.classList.remove("workplace-flex");
  workplace.classList.add("display-none");
  setBlockSizes();
  block.innerHTML = blockContent;
  block.classList.remove("padding-remove");
  playBtn.classList.remove("display-none");
  playCanvas.classList.remove("display-none");
};

const checkWhichSquare = (randNum, num, square, width) => {
  if (randNum == num) {
    square.style.left = width - 20 + "px";
    square.style.right = width + "px";
  } else {
    square.style.left = width + "px";
    square.style.right = width - 20 + "px";
  }
};

const generateSquare = () => {
  const imgsWrappers = document.querySelectorAll(
    ".left-block-body .anim-img-wrapper"
  );
  const randomNumber = Math.floor(Math.random() * 4);
  const imgWrapper = imgsWrappers[randomNumber];

  const square = document.createElement("div");
  square.classList.add("square");

  const anim = document.querySelector(".left-block-body .anim-default");

  const imgWidth = imgWrapper.clientWidth;
  const imgHeight = imgWrapper.clientHeight;

  if (randomNumber <= 1) {
    square.style.bottom = imgHeight + "px";
    checkWhichSquare(randomNumber, 0, square, imgWidth);
    square.style.top = imgHeight - 20 + "px";
  } else {
    square.style.bottom = imgHeight - 20 + "px";
    checkWhichSquare(randomNumber, 2, square, imgWidth);
    square.style.top = imgHeight + "px";
  }

  anim.append(square);
};

const restartAnimation = () => {
  cancelAnimationFrame(raf);
  dir = "right";
  counter = 0;
  raf = null;
  step = 0;
};

const startAnimation = () => {
  const square = document.querySelector(".square");
  const anim = document.querySelector(".left-block-body .anim-default");

  raf = requestAnimationFrame(startAnimation);
  if (++counter > 1) {
    if (
      parseInt(square.style.top) + 21 === anim.clientHeight ||
      parseInt(square.style.top) - 1 === 0 ||
      parseInt(square.style.left) + 20 === anim.clientWidth ||
      parseInt(square.style.left) - 1 === 0
    ) {
      const reloadBtn = document.querySelector(
        ".left-block-body .controls-reload"
      );
      const startBtn = document.querySelector(
        ".left-block-body .controls-start"
      );
      restartAnimation();
      startBtn.classList.add("display-none");
      reloadBtn.classList.remove("display-none");
      reloadBtn.addEventListener("click", (e) => {
        document.querySelector(".square").remove();
        e.target.classList.add("display-none");
        startBtn.classList.remove("display-none");
        startBtn.removeAttribute("disabled");
        generateSquare();
      });
    }
    counter = 0;
    ++step;
    switch (dir) {
      case "right":
        dir = "top";
        square.style.left = parseInt(square.style.left) + step + "px";
        console.log(square.style.top, square.style.left);
        break;
      case "top":
        dir = "left";
        square.style.top = parseInt(square.style.top) - step + "px";
        console.log(square.style.top, square.style.left);
        break;
      case "left":
        dir = "bottom";
        square.style.left = parseInt(square.style.left) - step + "px";
        console.log(square.style.top, square.style.left);
        break;
      case "bottom":
        dir = "right";
        square.style.top = parseInt(square.style.top) + step + "px";
        console.log(square.style.top, square.style.left);
        break;
      default:
        square.style.top = 0;
        square.style.left = 0;
        break;
    }
  }
};

const createBackground = () => {
  const img = new Image(canvas.width / 2, canvas.height / 2);
  img.src = "./muh1.jpg";
  for (let w = 0; w < canvas.width; w += img.width) {
    for (let h = 0; h < canvas.height; h += img.height) {
      ctx.drawImage(img, w, h, img.width, img.height);
    }
  }
};

const fillField = () => {
  createBackground();
  let points = [20, 0];

  x = canvas.width / 2 - points[Math.floor(Math.random() * 2)];
  y = canvas.height / 2 - points[Math.floor(Math.random() * 2)];

  ctx.fillStyle = "blue";
  ctx.fillRect(x, y, cell, cell);
};

const checkCanvasCollision = (interval) => {
  if (
    y === canvas.height - cell ||
    y === 1 ||
    x === canvas.width - cell ||
    x === 0
  ) {
    clearInterval(interval);
    const reloadBtn = document.querySelector(
      ".left-block-body .controls-reload"
    );
    const startBtn = document.querySelector(".left-block-body .controls-start");
    startBtn.classList.add("display-none");
    reloadBtn.classList.remove("display-none");
    reloadBtn.addEventListener("click", (e) => {
      e.target.classList.add("display-none");
      startBtn.classList.remove("display-none");
      startBtn.removeAttribute("disabled");
      closeWorkplace();
      createWorkplace("canvas");
    });
  }
};

const startCanvasAnimation = () => {
  step = 19;
  interval = setInterval(() => {
    createBackground();
    ctx.fillStyle = "blue";
    ++step;
    switch (dir) {
      case "right":
        dir = "top";
        x += step;
        console.log(x,y);
        break;
      case "top":
        dir = "left";
        y -= step;
        console.log(x,y);
        break;
      case "left":
        dir = "bottom";
        x -= step;
        console.log(x,y);
        break;
      case "bottom":
        dir = "right";
        y += step;
        console.log(x,y);
        break;
    }
    ctx.fillRect(x, y, cell, cell);
    checkCanvasCollision(interval);
  }, 20);
};

const createWorkplace = (type) => {
  playBtn.classList.add("display-none");
  playCanvas.classList.add("display-none");

  block.innerHTML = workplaceWrapper.innerHTML;

  const workplace = document.querySelector(".left-block-body .workplace");
  const closeBtn = document.querySelector(".left-block-body .controls-close");
  const startBtn = document.querySelector(".left-block-body .controls-start");
  setBlockSizes();

  block.classList.add("padding-remove");
  workplace.classList.remove("display-none");
  workplace.classList.add("workplace-flex");
  workplace.style.height = height.toString() + "px";
  closeBtn.addEventListener("click", closeWorkplace);

  if (type === "canvas") {
    workplace
      .querySelectorAll(".anim-img-wrapper")
      .forEach((w) => w.classList.add("display-none"));
    workplace.querySelector(".canvas").classList.remove("display-none");
    canvas = document.querySelector(".left-block-body .canvas");
    ctx = canvas.getContext("2d");
    fillField();
  } else {
    workplace
      .querySelectorAll(".anim-img-wrapper")
      .forEach((w) => w.classList.remove("display-none"));
    workplace.querySelector(".canvas").classList.add("display-none");
  }

  startBtn.addEventListener("click", (e) => {
    e.target.setAttribute("disabled", true);
    if (type === "default") {
      if (!document.querySelector(".square")) generateSquare();
      raf = requestAnimationFrame(startAnimation);
    } else {
      startCanvasAnimation();
    }
  });
};

playBtn.addEventListener("click", createWorkplace.bind(this, "default"));
playCanvas.addEventListener("click", createWorkplace.bind(this, "canvas"));
