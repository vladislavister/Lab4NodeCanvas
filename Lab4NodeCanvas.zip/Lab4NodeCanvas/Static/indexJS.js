const blocks = document.querySelectorAll(".block"); //все основные блоки, в которых можно поменять фон
const firstMessage = document.getElementById("special-text1");
const secondMessage = document.getElementById("special-text2");
const text1 = firstMessage.textContent;
firstMessage.textContent = secondMessage.textContent;
secondMessage.textContent = text1;

for (let i = 1; i < blocks.length; i++) {
  const backgroundImg = localStorage.getItem(`block-${i}`);
  if (backgroundImg) {
    const currentBlock = document.querySelector(`#block-${i}`);
    currentBlock.style.backgroundImage = `url(${backgroundImg})`;
  }
}

// function on_Click()
//{
//	var val1 = document.getElementById('input1').value;
//	var val2 = document.getElementById('input2');
//	var result = val1 * val2;
//	document.getElementById('result').innerHTML = result;
//}

let Sp = 2 * 3;
const S = document.getElementById("SParalelog");
S.textContent = "Ploscha paralelograma = " + Sp;

const bodyText = document.getElementById("body-text").textContent;
const textArr = bodyText.split(" ");
const wordsArr = [];

for (let i = 0; i < textArr.length; i++) {
  if (textArr[i] !== "" && textArr[i] !== "\n") {
    wordsArr.push(textArr[i]);
    console.log(wordsArr[i]);
  }
}

let AOW = wordsArr.length;
// alert(`Количество слов: ${wordsArr.length}`);
document.cookie = `AmountOfWords=${AOW}`;
// alert(`После нажатия Ок куки удалятся`);
document.cookie = "AmountOfWords=; max-age=0";

let storage_color = localStorage.getItem("color");
let color_choose = document.getElementById("color_choose");

let secondBlock = document.getElementById("block-2");
let color = storage_color ? storage_color : "black";
color_choose.value = color;

color_choose.addEventListener("change", () => {
  color = color_choose.value;
  localStorage.setItem("color", color);
});

secondBlock.onmouseout = function () {
  secondBlock.style.backgroundColor = "#6DAD76";
};
secondBlock.onmouseover = function () {
  secondBlock.style.backgroundColor = `${color}`;
};

const leftBlock = document.querySelector(".left-block-body");
const list = document.createElement("ol");
list.classList.add("settings-list");

// function addPictureInput(id, block) {
//   //функция для создания инпута и кнопок 1, 2
//   const generalWrapper = document.createElement("div");
//   const btnsWrapper = document.createElement("div");
//   const pictureInput = document.createElement("input");
//   const firstButton = document.createElement("button");
//   const secondButton = document.createElement("button");
//   firstButton.addEventListener("click", () => {
//     if (!pictureInput.value) return;
//     const picPath = pictureInput.files[0].name;
//     localStorage.setItem(`block-${id}`, picPath);
//     block.style.backgroundImage = `url(${picPath})`;
//   });
//   secondButton.addEventListener("click", () => {
//     block.style.backgroundImage = ``;
//     localStorage.removeItem(`block-${id}`);
//   });
//   btnsWrapper.classList.add("flex-wrapper");
//   pictureInput.setAttribute("type", "file");
//   pictureInput.setAttribute(`id`, `pictureInput-${id}`);
//   firstButton.setAttribute(`id`, `accept-${id}`);
//   secondButton.setAttribute(`id`, `deny-${id}`);
//   firstButton.classList.add("settings-btn");
//   secondButton.classList.add("settings-btn");
//   firstButton.textContent = "1";
//   secondButton.textContent = "2";
//   btnsWrapper.append(firstButton);
//   btnsWrapper.append(secondButton);
//   generalWrapper.append(pictureInput);
//   generalWrapper.append(btnsWrapper);
//   block.append(generalWrapper);
// }
//
// for (let i = 1; i < 6; i++) {
//   const listItem = document.createElement("li");
//   listItem.classList.add("settings-list-item");
//   const button = document.createElement("button");
//   button.setAttribute(`id`, `${i}`);
//   button.classList.add("settings-btn");
//   button.textContent = `Блок ${i}`;
//   button.addEventListener("click", () => {
//     // на каждую кнопку вешается обработчик
//     if (button.classList.contains("clicked")) return;
//     button.classList.add("clicked"); //нажатой кнопке дается класс
//     const block = document.getElementById(`block-${i}`);
//     if (block.textContent.trim()) {
//       //trim обрезает все пустое пространство (пробелы), потому что без него в блоке пробелы будут считаться за текст
//       addPictureInput(i, block);
//     } else {
//       const refusalText = document.createElement("p");
//       refusalText.textContent = "Нет текста";
//       refusalText.classList.add("refusal-text");
//       button.append(refusalText);
//     }
//   });
//   listItem.append(button);
//   list.append(listItem);
// }
//
// leftBlock.append(list);

// бар

// едит бара

// const fs = require("fs");
// const path = require("path");
// const filePath = path.join(__dirname, "test", "text.txt");

// function addDataInput() {
//   const generalWrapper = document.createElement("div");
//   const btnsWrapper = document.createElement("div");
//   const textInput = document.createElement("input");
//   const firstButton = document.createElement("button");

//   firstButton.addEventListener("click", () => {
//     if (!textInput.value) return;
//     const AllText = textInput.textContent;
//     fs.writeFile(filePath, textInput.textContent, (err) => {
//       if (err) {
//         throw err;
//       }
//     });
//   });
// }

const path = window.location.pathname;
const page = path.split("/").pop();

if (page === "") {
  const form = document.querySelector(".express-form");
  const input = form.querySelector(".form-input");

  const sendInputData = async (data) => {
    const response = await fetch("http://localhost:3000/submit-form", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });
    return response.json();
  };

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = input.value;
    sendInputData({ text }).then((res) => {
      console.log(res);
    });
    input.value = "";
  });
} else if (page === "index2.html") {
  const bar = document.querySelector("#text");
  fetch("http://localhost:3000/get-file-content")
    .then((res) => {
      return res.json();
    })
    .then((res) => {
      console.log(res);
      bar.textContent = res.fileText;
    });
}
